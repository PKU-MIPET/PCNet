The official repo for paper "“PCNet: Prior Category Network for CT Universal Segmentation Model"
![node-edgeHCS](./node-edgeHCS.png)
